from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, abort
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from datetime import datetime
import os
from config import Config
from werkzeug.security import generate_password_hash, check_password_hash
from models import db
from functools import wraps

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Import models
from models.user import User
from models.quiz import Quiz, QuizAttempt

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return decorated_function

@login_manager.user_loader
def load_user(user_id):
    return User.get_by_id(user_id)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.get_by_email(email)

        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))

        flash('Invalid email or password.', 'error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role')

        if User.get_by_email(email):
            flash('Email already registered.', 'error')
            return redirect(url_for('register'))

        user = User(
            email=email,
            name=full_name,
            password=password,
            is_admin=False,
            is_educator=(role == 'educator')
        )
        user.save()

        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    available_quizzes = Quiz.get_available_quizzes()
    quiz_history = QuizAttempt.get_user_history(current_user._id)
    return render_template('dashboard.html', quizzes=available_quizzes, history=quiz_history)

@app.route('/create_quiz', methods=['GET', 'POST'])
@login_required
def create_quiz():
    if not (current_user.is_educator or current_user.is_admin):
        flash('Only educators and admins can create quizzes', 'error')
        return redirect(url_for('dashboard'))

    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        category = request.form.get('category')
        difficulty = request.form.get('difficulty')
        time_limit = request.form.get('time_limit')

        # Create new quiz
        quiz = Quiz(
            title=title,
            description=description,
            category=category,
            difficulty=difficulty,
            questions=[],  # Will be populated with questions
            created_by=current_user._id,
            time_limit=int(time_limit) if time_limit else None
        )

        # Add questions
        question_count = int(request.form.get('question_count', 0))
        for i in range(question_count):
            question_text = request.form.get(f'question_{i}')
            question_type = request.form.get(f'question_type_{i}')
            correct_answer = request.form.get(f'correct_answer_{i}')
            points = int(request.form.get(f'points_{i}', 1))

            options = None
            if question_type == 'multiple_choice':
                options = [
                    request.form.get(f'option_{i}_1'),
                    request.form.get(f'option_{i}_2'),
                    request.form.get(f'option_{i}_3'),
                    request.form.get(f'option_{i}_4')
                ]

            quiz.add_question(
                question_text=question_text,
                question_type=question_type,
                correct_answer=correct_answer,
                options=options,
                points=points
            )

        quiz.save()
        flash('Quiz created successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('create_quiz.html')

@app.route('/quiz/<quiz_id>')
@login_required
def take_quiz(quiz_id):
    quiz = Quiz.get_by_id(quiz_id)
    if not quiz:
        flash('Quiz not found.', 'error')
        return redirect(url_for('dashboard'))

    # Check if user has already taken this quiz
    if QuizAttempt.has_user_taken_quiz(current_user._id, quiz_id):
        flash('You have already taken this quiz.', 'error')
        return redirect(url_for('dashboard'))

    return render_template('quiz.html', quiz=quiz)

@app.route('/quiz/<quiz_id>/submit', methods=['POST'])
@login_required
def submit_quiz(quiz_id):
    try:
        print(f"DEBUG: Submit quiz called with quiz_id: {quiz_id}")
        print(f"DEBUG: Request method: {request.method}")
        print(f"DEBUG: Request headers: {dict(request.headers)}")
        print(f"DEBUG: Form data: {request.form}")

        quiz = Quiz.get_by_id(quiz_id)
        print(f"DEBUG: Quiz retrieved: {quiz is not None}")

        if not quiz:
            print("DEBUG: Quiz not found")
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'error': 'Quiz not found'}), 404
            flash('Quiz not found.', 'error')
            return redirect(url_for('dashboard'))

        # Check if user has already taken this quiz
        if QuizAttempt.has_user_taken_quiz(current_user._id, quiz_id):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'error': 'You have already taken this quiz'}), 400
            flash('You have already taken this quiz.', 'error')
            return redirect(url_for('dashboard'))

        answers = request.form.getlist('answers[]')
        print(f"DEBUG: Answers received: {answers}")
        print(f"DEBUG: Number of questions: {len(quiz.questions)}")
        print(f"DEBUG: Number of answers: {len(answers)}")

        # Validate that we have answers for all questions
        if len(answers) != len(quiz.questions):
            print(f"DEBUG: Answer count mismatch - expected {len(quiz.questions)}, got {len(answers)}")
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'error': f'Please answer all questions. Expected {len(quiz.questions)}, got {len(answers)}'}), 400
            flash('Please answer all questions.', 'error')
            return redirect(url_for('take_quiz', quiz_id=quiz_id))

        # Check for empty answers
        if any(not answer.strip() for answer in answers):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'error': 'Please answer all questions'}), 400
            flash('Please answer all questions.', 'error')
            return redirect(url_for('take_quiz', quiz_id=quiz_id))

        # Calculate score
        score = 0
        total_points = 0
        for i, (question, answer) in enumerate(zip(quiz.questions, answers)):
            points = question.get('points', 1)
            total_points += points
            if answer.lower().strip() == question['correct_answer'].lower().strip():
                score += points

        # Save attempt
        print(f"DEBUG: Saving attempt with score {score}/{total_points}")
        attempt = QuizAttempt(
            user_id=current_user._id,
            quiz_id=quiz_id,
            score=score,
            total_questions=len(quiz.questions),
            answers=answers,
            completed_at=datetime.utcnow()
        )
        attempt.save()
        print("DEBUG: Attempt saved successfully")

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            response_data = {
                'score': score,
                'total': total_points,
                'percentage': (score / total_points * 100) if total_points > 0 else 0
            }
            print(f"DEBUG: Returning JSON response: {response_data}")
            return jsonify(response_data)

        flash(f'Quiz completed! Your score: {score}/{total_points}', 'success')
        return redirect(url_for('dashboard'))

    except Exception as e:
        print(f"Error in submit_quiz: {str(e)}")  # For debugging
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error': 'An error occurred while processing your submission. Please try again.'}), 500
        flash('An error occurred while submitting the quiz. Please try again.', 'error')
        return redirect(url_for('dashboard'))

# Admin routes
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    users = User.get_all_users()
    quizzes = Quiz.get_all_quizzes()
    return render_template('admin.html', users=users, quizzes=quizzes)

@app.route('/admin/user/<user_id>/role', methods=['POST'])
@login_required
@admin_required
def update_user_role(user_id):
    user = User.get_by_id(user_id)
    if not user:
        flash('User not found', 'error')
        return redirect(url_for('admin_dashboard'))

    role = request.form.get('role')
    if role == 'admin':
        user.is_admin = True
        user.is_educator = False
    elif role == 'educator':
        user.is_admin = False
        user.is_educator = True
    else:  # student
        user.is_admin = False
        user.is_educator = False

    user.save()
    flash(f'User role updated to {role}', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/quiz/<quiz_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_quiz(quiz_id):
    quiz = Quiz.get_by_id(quiz_id)
    if not quiz:
        flash('Quiz not found', 'error')
        return redirect(url_for('admin_dashboard'))

    if request.method == 'POST':
        quiz.title = request.form.get('title')
        quiz.description = request.form.get('description')
        quiz.category = request.form.get('category')
        quiz.difficulty = request.form.get('difficulty')
        quiz.time_limit = int(request.form.get('time_limit')) if request.form.get('time_limit') else None

        # Update questions
        quiz.questions = []
        question_count = int(request.form.get('question_count', 0))
        for i in range(question_count):
            question_text = request.form.get(f'question_{i}')
            question_type = request.form.get(f'question_type_{i}')
            correct_answer = request.form.get(f'correct_answer_{i}')
            points = int(request.form.get(f'points_{i}', 1))

            options = None
            if question_type == 'multiple_choice':
                options = [
                    request.form.get(f'option_{i}_1'),
                    request.form.get(f'option_{i}_2'),
                    request.form.get(f'option_{i}_3'),
                    request.form.get(f'option_{i}_4')
                ]

            quiz.add_question(
                question_text=question_text,
                question_type=question_type,
                correct_answer=correct_answer,
                options=options,
                points=points
            )

        quiz.save()
        flash('Quiz updated successfully!', 'success')
        return redirect(url_for('admin_dashboard'))

    return render_template('edit_quiz.html', quiz=quiz)

@app.route('/admin/quiz/<quiz_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_quiz(quiz_id):
    quiz = Quiz.get_by_id(quiz_id)
    if not quiz:
        flash('Quiz not found', 'error')
        return redirect(url_for('admin_dashboard'))

    quiz.delete()
    flash('Quiz deleted successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/make_admin/<email>')
def make_admin(email):
    user = User.get_by_email(email)
    if user:
        user.is_admin = True
        user.save()
        flash(f'User {email} is now an admin!', 'success')
    else:
        flash('User not found', 'error')
    return redirect(url_for('login'))

if __name__ == '__main__':
    import sys
    print("Starting Flask application...", flush=True)
    print(f"MongoDB URI: {app.config.get('MONGO_URI')}", flush=True)
    sys.stdout.flush()
    app.run(debug=True, host='127.0.0.1', port=5000)