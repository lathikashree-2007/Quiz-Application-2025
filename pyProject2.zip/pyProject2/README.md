# Online Quiz Platform

A comprehensive online quiz platform that allows educators to create and manage quizzes, while users can take quizzes and track their progress.

## Features

- Create quizzes with multiple-choice, short answer, or true/false questions
- Timed quizzes with immediate feedback
- Track quiz history and scores
- Categorize quizzes by subject, difficulty, and topic
- Admin dashboard for performance reports

## Setup Instructions

1. Create a virtual environment:
```bash
python -m venv venv
```

2. Activate the virtual environment:
- Windows:
```bash
venv\Scripts\activate
```
- Unix/MacOS:
```bash
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Initialize the database:
```bash
python init_db.py
```

5. Run the application:
```bash
python app.py
```

6. Access the application at `http://localhost:5000`

## Project Structure

```
├── app.py              # Main application file
├── config.py           # Configuration settings
├── models/            # Database models
├── static/            # Static files (CSS, JS, images)
├── templates/         # HTML templates
└── requirements.txt   # Python dependencies
``` 