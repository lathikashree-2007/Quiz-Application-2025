#!/usr/bin/env python3
"""
Test script to check database connectivity and basic functionality
"""

import sys
import os
from datetime import datetime

# Add the current directory to the path so we can import our modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from flask import Flask
    from config import Config
    from models import db
    from models.user import User
    from models.quiz import Quiz, QuizAttempt
    
    print("✓ All imports successful")
    
    # Create a test Flask app
    app = Flask(__name__)
    app.config.from_object(Config)
    
    print(f"✓ Flask app created with config: {app.config.get('MONGO_URI')}")
    
    # Initialize database
    with app.app_context():
        db.init_app(app)
        print("✓ Database initialized")
        
        # Test database connection
        try:
            # Try to access the database
            collections = db.db.list_collection_names()
            print(f"✓ Database connection successful. Collections: {collections}")
            
            # Test creating a simple user
            test_user = User(
                email="test@example.com",
                name="Test User",
                password="testpass",
                is_admin=False,
                is_educator=False
            )
            
            # Check if user already exists
            existing_user = User.get_by_email("test@example.com")
            if existing_user:
                print("✓ Test user already exists")
            else:
                user_id = test_user.save()
                print(f"✓ Test user created with ID: {user_id}")
            
            # Test creating a simple quiz
            test_quiz = Quiz(
                title="Test Quiz",
                description="A simple test quiz",
                category="Test",
                difficulty="Easy",
                questions=[
                    {
                        'question_text': 'What is 2+2?',
                        'question_type': 'multiple_choice',
                        'correct_answer': '4',
                        'options': ['2', '3', '4', '5'],
                        'points': 1
                    }
                ],
                created_by=existing_user._id if existing_user else test_user._id,
                time_limit=10
            )
            
            quiz_id = test_quiz.save()
            print(f"✓ Test quiz created with ID: {quiz_id}")
            
            # Test retrieving the quiz
            retrieved_quiz = Quiz.get_by_id(quiz_id)
            if retrieved_quiz:
                print(f"✓ Quiz retrieved successfully: {retrieved_quiz.title}")
            else:
                print("✗ Failed to retrieve quiz")
            
            print("\n🎉 All database tests passed! The submit functionality should work now.")
            
        except Exception as e:
            print(f"✗ Database connection failed: {str(e)}")
            print("\n💡 Possible solutions:")
            print("1. Make sure MongoDB is installed and running")
            print("2. Check if MongoDB is running on localhost:27017")
            print("3. Try starting MongoDB with: mongod")
            print("4. Or install MongoDB Community Edition from: https://www.mongodb.com/try/download/community")
            
except ImportError as e:
    print(f"✗ Import error: {str(e)}")
    print("Make sure all required packages are installed:")
    print("pip install -r requirements.txt")
    
except Exception as e:
    print(f"✗ Unexpected error: {str(e)}")
