from flask_pymongo import PyMongo

db = PyMongo() 