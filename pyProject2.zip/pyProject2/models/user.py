from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from bson.objectid import ObjectId
from datetime import datetime
from models import db

class User(UserMixin):
    def __init__(self, email=None, name=None, password=None, is_admin=False, is_educator=False):
        self.email = email
        self.name = name
        self.password_hash = None
        self.is_admin = is_admin
        self.is_educator = is_educator
        self.created_at = datetime.utcnow()
        if password:
            self.set_password(password)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return str(self._id) if hasattr(self, '_id') else None

    @staticmethod
    def get_by_id(user_id):
        user_data = db.db.users.find_one({'_id': ObjectId(user_id)})
        if user_data:
            user = User()
            user._id = user_data['_id']
            user.email = user_data['email']
            user.name = user_data['name']
            user.password_hash = user_data['password_hash']
            user.is_admin = user_data.get('is_admin', False)
            user.is_educator = user_data.get('is_educator', False)
            user.created_at = user_data.get('created_at', datetime.utcnow())
            return user
        return None

    @staticmethod
    def get_by_email(email):
        user_data = db.db.users.find_one({'email': email})
        if user_data:
            user = User()
            user._id = user_data['_id']
            user.email = user_data['email']
            user.name = user_data['name']
            user.password_hash = user_data['password_hash']
            user.is_admin = user_data.get('is_admin', False)
            user.is_educator = user_data.get('is_educator', False)
            user.created_at = user_data.get('created_at', datetime.utcnow())
            return user
        return None

    def save(self):
        user_data = {
            'email': self.email,
            'name': self.name,
            'password_hash': self.password_hash,
            'is_admin': self.is_admin,
            'is_educator': self.is_educator,
            'created_at': self.created_at
        }
        if hasattr(self, '_id'):
            db.db.users.update_one({'_id': self._id}, {'$set': user_data})
        else:
            result = db.db.users.insert_one(user_data)
            self._id = result.inserted_id
        return self

    def __repr__(self):
        return f'<User {self.email}>'

    @staticmethod
    def get_all_users():
        users = []
        for user_data in db.db.users.find():
            user = User(
                email=user_data['email'],
                name=user_data['name'],
                is_admin=user_data.get('is_admin', False),
                is_educator=user_data.get('is_educator', False)
            )
            user._id = user_data['_id']
            user.password_hash = user_data['password_hash']
            user.created_at = user_data.get('created_at', datetime.utcnow())
            users.append(user)
        return users