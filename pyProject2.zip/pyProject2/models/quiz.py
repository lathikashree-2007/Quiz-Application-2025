from bson.objectid import ObjectId # type: ignore
from datetime import datetime
from config import Config
from models import db

class Quiz:
    def __init__(self, title, description, category, difficulty, questions, created_by, time_limit=None):
        self.title = title
        self.description = description
        self.category = category
        self.difficulty = difficulty
        self.questions = questions
        self.created_by = created_by
        self.time_limit = time_limit
        self.created_at = datetime.utcnow()

    def save(self):
        quiz_data = {
            'title': self.title,
            'description': self.description,
            'category': self.category,
            'difficulty': self.difficulty,
            'questions': self.questions,
            'created_by': self.created_by,
            'time_limit': self.time_limit,
            'created_at': self.created_at
        }
        if hasattr(self, '_id'):
            db.db.quizzes.update_one({'_id': self._id}, {'$set': quiz_data})
        else:
            result = db.db.quizzes.insert_one(quiz_data)
            self._id = result.inserted_id
        return self._id

    def delete(self):
        if hasattr(self, '_id'):
            db.db.quizzes.delete_one({'_id': self._id})
            return True
        return False

    @staticmethod
    def get_by_id(quiz_id):
        try:
            quiz_data = db.db.quizzes.find_one({'_id': ObjectId(quiz_id)})
            if quiz_data:
                quiz = Quiz(
                    title=quiz_data['title'],
                    description=quiz_data['description'],
                    category=quiz_data['category'],
                    difficulty=quiz_data['difficulty'],
                    questions=quiz_data['questions'],
                    created_by=quiz_data['created_by'],
                    time_limit=quiz_data.get('time_limit')
                )
                quiz._id = quiz_data['_id']
                quiz.created_at = quiz_data['created_at']
                return quiz
            return None
        except Exception as e:
            print(f"Error getting quiz by ID {quiz_id}: {str(e)}")
            return None

    @staticmethod
    def get_available_quizzes():
        quizzes = []
        for quiz_data in db.db.quizzes.find():
            quiz = Quiz(
                title=quiz_data['title'],
                description=quiz_data['description'],
                category=quiz_data['category'],
                difficulty=quiz_data['difficulty'],
                questions=quiz_data['questions'],
                created_by=quiz_data['created_by'],
                time_limit=quiz_data.get('time_limit')
            )
            quiz._id = quiz_data['_id']
            quiz.created_at = quiz_data['created_at']
            quizzes.append(quiz)
        return quizzes

    @staticmethod
    def get_all_quizzes():
        quizzes = []
        for quiz_data in db.db.quizzes.find():
            quiz = Quiz(
                title=quiz_data['title'],
                description=quiz_data['description'],
                category=quiz_data['category'],
                difficulty=quiz_data['difficulty'],
                questions=quiz_data['questions'],
                created_by=quiz_data['created_by'],
                time_limit=quiz_data.get('time_limit')
            )
            quiz._id = quiz_data['_id']
            quiz.created_at = quiz_data['created_at']
            # Get creator's name
            creator = db.db.users.find_one({'_id': quiz_data['created_by']})
            if creator:
                quiz.creator = {'name': creator['name']}
            else:
                quiz.creator = {'name': 'Unknown'}
            quizzes.append(quiz)
        return quizzes

    def add_question(self, question_text, question_type, correct_answer, options=None, points=1):
        question = {
            'question_text': question_text,
            'question_type': question_type,
            'correct_answer': correct_answer,
            'options': options,
            'points': points
        }
        self.questions.append(question)
        return question

    def check_answer(self, question_index, user_answer):
        if 0 <= question_index < len(self.questions):
            question = self.questions[question_index]
            if question['question_type'] == 'multiple_choice':
                return user_answer == question['correct_answer']
            elif question['question_type'] == 'true_false':
                return user_answer.lower() == question['correct_answer'].lower()
            else:  # short_answer
                return user_answer.lower().strip() == question['correct_answer'].lower().strip()
        return False

class QuizAttempt:
    def __init__(self, user_id, quiz_id, score, total_questions, answers, completed_at):
        self.user_id = user_id
        self.quiz_id = quiz_id
        self.score = score
        self.total_questions = total_questions
        self.answers = answers
        self.completed_at = completed_at

    def save(self):
        try:
            attempt_data = {
                'user_id': self.user_id,
                'quiz_id': self.quiz_id,
                'score': self.score,
                'total_questions': self.total_questions,
                'answers': self.answers,
                'completed_at': self.completed_at
            }
            result = db.db.quiz_attempts.insert_one(attempt_data)
            self._id = result.inserted_id
            return self._id
        except Exception as e:
            print(f"Error saving quiz attempt: {str(e)}")
            raise e

    @staticmethod
    def get_user_history(user_id):
        attempts = []
        for attempt_data in db.db.quiz_attempts.find({'user_id': user_id}).sort('completed_at', -1):
            attempt = QuizAttempt(
                user_id=attempt_data['user_id'],
                quiz_id=attempt_data['quiz_id'],
                score=attempt_data['score'],
                total_questions=attempt_data['total_questions'],
                answers=attempt_data['answers'],
                completed_at=attempt_data['completed_at']
            )
            attempt._id = attempt_data['_id']
            # Get quiz details
            quiz = Quiz.get_by_id(attempt_data['quiz_id'])
            if quiz:
                attempt.quiz = quiz
            attempts.append(attempt)
        return attempts

    @staticmethod
    def has_user_taken_quiz(user_id, quiz_id):
        try:
            return db.db.quiz_attempts.find_one({'user_id': user_id, 'quiz_id': quiz_id}) is not None
        except Exception as e:
            print(f"Error checking if user has taken quiz: {str(e)}")
            return False